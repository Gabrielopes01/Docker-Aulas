<!DOCTYPE html>
<html>
<head>
    <title>My Posts</title>
    <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
</head>
<body>
    <div class="container mx-auto my-4">
        <h4 class="text-lg"><?php echo e($fromCache ? 'From Cache' : 'Not From Cache'); ?></h4>
        <div class="grid grid-cols-3 gap-6">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="post">
                    <h3 class="text-xl"><?php echo e($post->title); ?></h3>
                    <p class="font-light"><?php echo e($post->content); ?></p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</body>
</html><?php /**PATH /var/www/html/resources/views/posts.blade.php ENDPATH**/ ?>